<?php
  use RedBeanPHP\R as R;

  $date = [];
  $uzb_count = [];
  $cli_count = [];
  $i = 0;
  $m_sum = 0;
  $m_cli_sum = 0;
  while($i != 30) {

    $sum = 0;
    $cli_sum = 0;
    
    $tm = date("Y-m-d", strtotime('-'.$i.' day', time()));

    $posts = R::findAll("posts");

    foreach ($posts as $val) {
      $dt = explode(" ", $val -> uzbekistan_date);
      if($dt[0] == $tm) {
        $sum++;
      }

      $dt2 = explode(" ", $val -> client_date);
      if($dt2[0] == $tm) {
        $cli_sum++;
      }
    }

    $date[] = (string)$tm;
    $uzb_count[] = $sum;
    $cli_count[] = $cli_sum;

    $m_sum += $sum;
    $m_cli_sum += $cli_sum;

    $i++;
  }

  $dates = "['" . implode("', '", array_reverse($date)) . "']";
  $uc = '[' . implode(', ', array_reverse($uzb_count)) . ']';
  $cc = '[' . implode(', ', array_reverse($cli_count)) . ']';


?>


<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title>Admin </title>
  <meta content="" name="description">
  <meta content="" name="keywords">

  <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

  <link href="assets/img/favicon.png" rel="icon">
  <link href="assets/img/apple-touch-icon.png" rel="apple-touch-icon">

  <link href="https://fonts.gstatic.com" rel="preconnect">
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Nunito:300,300i,400,400i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
  <link href="assets/vendor/quill/quill.snow.css" rel="stylesheet">
  <link href="assets/vendor/quill/quill.bubble.css" rel="stylesheet">
  <link href="assets/vendor/remixicon/remixicon.css" rel="stylesheet">
  <link href="assets/vendor/simple-datatables/style.css" rel="stylesheet">

  <link href="assets/css/style.css" rel="stylesheet">

</head>

<body class="toggle-sidebar">

  <!-- ======= Header ======= -->
  <header id="header" class="header fixed-top d-flex align-items-center">

    <div class="d-flex align-items-center justify-content-between">
      <a href="/admin" class="logo d-flex align-items-center">
        <img  src="assets/img/abduganiev.png" alt="">
      </a>
      <?php echo $__env->make('blocks.notification', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div><!-- End Logo -->
  </header><!-- End Header -->

  <!-- ======= Sidebar ======= -->


  <main id="main" class="main">

    <div class="pagetitle">
      <h1>Asosiy sahifa</h1>
      <nav>
        <ol class="breadcrumb">
          <li class="breadcrumb-item active"><a href="/admin">Asosiy sahifa</a></li>
        </ol>
      </nav>
    </div><!-- End Page Title -->

    <section class="section dashboard">
      <div class="row">

        
        <!-- Right side columns -->
        <div class="col-lg-4">

          <!-- Recent Activity -->
          <div class="card">
            <div class="card-body">
              <h5 class="card-title">Yukni topish:</h5>

              <div class="row mb-3">
                <div class="col-sm-10">
                  <input type="text" id="search" placeholder="ID & F.I.O & Tel" class="form-control">
                </div>
                <button id="search_client" type="button" class="col-sm-2 btn btn-primary mt-2 mt-md-0">
                  <i class="bi bi-search"></i>  
                </button>
              </div>

            </div>
          </div><!-- End Recent Activity -->

          <!-- Recent Activity -->
          <div class="card">
            <div class="card-body">
              <h5 class="card-title">Yukni Omborxonaga kelganni tasdiqlash:</h5>

              <div class="row mb-3">
                <div class="col-sm-10">
                  <input type="text" id="track_no" placeholder="Track №" class="form-control">
                </div>
                <button id="track_no_change" type="button" class="col-sm-2 btn btn-primary mt-2 mt-md-0">
                  <i class="bi bi-search"></i>  
                </button>
              </div>

            </div>
          </div><!-- End Recent Activity -->

          <!-- Recent Activity -->
          <div class="card">
            <div class="card-body">
              <h5 class="card-title">Yangi Mijoz qo'shish:</h5>

              <form method="POST" action="<?php echo e(route('CreateClient')); ?>" class="row mb-3 justify-content-center">
                <?php echo csrf_field(); ?>
                <div class="col-sm-12 mb-3">
                  <input type="text" placeholder="F.I.O" name="fio" minlength="4" maxlength="50" class="form-control" required>
                </div>
                <div class="col-sm-12 mb-3">
                  <input type="text" placeholder="Tel.raqam" name="phone" minlength="4" maxlength="50" class="form-control" required>
                </div>
                <div class="col-sm-12 mb-3">
                  <input type="text" placeholder="ID ruchnoy 14S" name="clid" minlength="2" maxlength="50" class="form-control" required>
                </div>
                <button type="submit"  class="col-sm-4 btn btn-primary btn-large">Yaratish </button>
              </form>

            </div>
          </div><!-- End Recent Activity -->

          <!-- Budget Report -->
          <div class="card">
           

          
          </div><!-- End Budget Report -->

          <!-- Website Traffic -->
          <div class="card">
           

            <div class="card-body pb-5">
              <h5 class="card-title">Kunlik statistika:</h5>

              <ul class="list-group">
                <li class="list-group-item d-flex justify-content-between align-items-center">
                  Omborxonaga kirib kelgan yuklar:
                  <span class="badge bg-primary rounded-pill"> <?php echo e($m_sum); ?> ta</span>
                </li>
                <li class="list-group-item d-flex justify-content-between align-items-center">
                  Mijozga berilgan yuklar:
                  <span class="badge bg-primary rounded-pill"> <?php echo e($m_cli_sum); ?> ta</span>
                </li>
               
              </ul>

               <!-- Bar Chart -->
               <canvas id="line-chart" width="800" height="450"></canvas>
              
               <!-- End Bar CHart -->

            </div>
          </div><!-- End Website Traffic -->

          

        </div><!-- End Right side columns -->


        <!-- Left side columns -->
        <div class="col-lg-8  d-flex flex-column align-items-center justify-content-between">
          <div class="row w-100">
            <!-- Recent Sales -->
            <div class="col-12">
              <div class="card recent-sales overflow-auto">

                

                <div class="card-body">
                  <h5 class="card-title">Klientlar<span></span></h5>
                  
                  <span id="clients_table"></span>

                </div>

              </div>
            </div><!-- End Recent Sales -->

            
            
          </div>
          
        </div><!-- End Left side columns -->

      </div>
    </section>

  </main><!-- End #main -->

  <!-- ======= Footer ======= -->
  <footer id="footer" class="footer">
    <div class="copyright">
      &copy; Copyright <strong><a href="https://abduganiev.uz/">ABDUGANIEV TECHNOLOGY</a></strong>. All Rights Reserved
    </div>
  </footer><!-- End Footer -->

  <a href="#" class="back-to-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>

  <script>
    const dates = <?php echo $dates; ?>;
    const uc = <?php echo e($uc); ?>;
    const cc = <?php echo e($cc); ?>;

    const req_url_search_table = "<?php echo e(route('SearchClient')); ?>";
    const req_url_sontinue_post = "<?php echo e(route('ContinuePost')); ?>";
  </script>

  <!-- Vendor JS Files -->
  <script src="assets/vendor/apexcharts/apexcharts.min.js"></script>
  <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="assets/vendor/chart.js/chart.umd.js"></script>
  <script src="assets/vendor/echarts/echarts.min.js"></script>
  <script src="assets/vendor/quill/quill.min.js"></script>
  <script src="assets/vendor/simple-datatables/simple-datatables.js"></script>
  <script src="assets/vendor/tinymce/tinymce.min.js"></script>
  <script src="assets/vendor/php-email-form/validate.js"></script>

  <!-- Template Main JS File -->
  <script src="assets/js/main.js"></script>

  <?php echo app('Illuminate\Foundation\Vite')('resources/js/admin.js'); ?>

</body>

</html><?php /**PATH /home/temurumaru/Документы/projects/php/poststagemanager/resources/views/admin/admin.blade.php ENDPATH**/ ?>