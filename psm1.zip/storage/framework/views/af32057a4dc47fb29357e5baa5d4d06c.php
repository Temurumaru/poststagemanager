<?php if($errors->any() || session('success')): ?>
  <div class="err-claster shadow-all">
    <?php if(isset($errors)): ?>
      <?php if($errors->any()): ?>
        <div class="tst tst-err">
          <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <p><?php echo e($error); ?></p>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
      <?php endif; ?>
    <?php endif; ?>
    <?php if(session('warning')): ?>
      <div class="tst tst-warr"><?php echo e(session('warning')); ?></div>
    <?php endif; ?>
    
    <?php if(session('success')): ?>
      <div class="tst tst-succ"><?php echo e(session('success')); ?></div>
    <?php endif; ?>
  </div>
<?php endif; ?><?php /**PATH /home/temurumaru/Документы/projects/php/poststagemanager/resources/views/blocks/notification.blade.php ENDPATH**/ ?>